console.log("Quiz Me Now: Content script running...");chrome.runtime.sendMessage({type:"PAGE_CONTENT",text:document.body.innerText||"No content found"});
